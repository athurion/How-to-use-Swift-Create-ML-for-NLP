//Import the Frameworks
import Foundation
import CreateML

//Load the Dataset. Make sure to change the path first.
let dataSet = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/YourUsername/Desktop/NLPPractice/sentimentAnalysis.csv"))

//Split training and testing data
let(trainingData, testingData) = dataSet.randomSplit(by: 0.8, seed: 5)

//Define the classifier
let sentimentClassifier = try MLTextClassifier(trainingData: trainingData, textColumn: "text", labelColumn: "class")

//Define the evaluation
let evaluationMetrics = sentimentClassifier.evaluation(on: testingData, textColumn: "text", labelColumn: "class")

//Create metadata
let metaData = MLModelMetadata(
    author: "Arc Sosangyo",
    shortDescription: "Sentiment classifier for published tutorial on medium",
    license: "CC0",
    version: "2.0"
)
 
//Export the model. Make sure to change the path first.
try sentimentClassifier.write(to: URL(fileURLWithPath: "/Users/YourUsername/Desktop/NLPPractice/SentimentClassifier.mlmodel"))

//Test the model
try sentimentClassifier.prediction(from: "Kudos to this awesome team")
try sentimentClassifier.prediction(from: "This is an awful company")
